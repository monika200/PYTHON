# Adavantages

Resource Management

Scalability
