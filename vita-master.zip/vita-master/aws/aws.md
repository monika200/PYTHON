

# Aws cloud 
## cloud
cloud is a term referred to storing and accessing data over the internet.
It doesn't store any data on the hard disk of your personal computer. In cloud computing, you can access data from a remote server.
![Cloud image](https://github.com/mukund1995/vita/blob/master/aws/images/cloud.png)

##  Advantages
* **Cost Savings:** It helps you to save substantial capital cost as it does not need any physical hardware investments.Also, you do not need trained personnel to maintain the hardware.The buying and managing of equipment is done by the cloud service provider.
* **Strategic edge:** It helps you to access the latest and applications any time without spending your time and money on installations.
* **High Speed:** Cloud computing allows you to deploy your service quickly in fewer clicks. This faster deployment allows you to get the resources required for your system within fewer minutes.
* **Back-up and restore data:** Once the data is stored in a Cloud, it is easier to get the back-up and recovery of that, which is otherwise very time taking process on-premise.
* **Reliability:** Reliability is one of the biggest pluses of cloud computing. You can always get instantly updated about the changes.
* **Mobility:** Employees who are working on the premises or at the remote locations can easily access all the could services. All they need is an Internet connectivity.
* **Unlimited storage capacity:** The cloud offers almost limitless storage capacity. At any time you can quickly expand your storage capacity with very nominal monthly fees.
* **Collaboration:** The cloud computing platform helps employees who are located in different geographies to collaborate in a highly convenient and secure manner.
* **Quick Deployment:** Last but not least, cloud computing gives you the advantage of rapid deployment. So, when you decide to use the cloud, your entire system can be fully functional in very few minutes. Although, the amount of time taken depends on what kind of technologies are used in your business.
