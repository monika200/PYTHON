# AWS
**Amazon Web Services (AWS)** is a secure cloud services platform, offering compute power, database storage, content delivery and other functionality to help businesses scale and grow.
